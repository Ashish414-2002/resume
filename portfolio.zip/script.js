        // DOM Elements
        const preloader = document.getElementById('preloader');
        const scrollToTopBtn = document.getElementById('scrollToTop');
        const hamburger = document.getElementById('hamburger');
        const navMenu = document.getElementById('navMenu');
        const mobileOverlay = document.getElementById('mobileOverlay');
        const themeToggle = document.getElementById('themeToggle');
        const themeIcon = themeToggle.querySelector('i');
        const navLinks = document.querySelectorAll('.nav-link');
        const filterBtns = document.querySelectorAll('.filter-btn');
        const portfolioItems = document.querySelectorAll('.portfolio-item');
        const photographyItems = document.querySelectorAll('.photography-item');
        const contactForm = document.getElementById('contactForm');
        const skillProgressBars = document.querySelectorAll('.skill-progress');
        const scrollDownIndicator = document.querySelector('.scroll-down');
        
        // Lightbox Elements
        const lightboxModal = document.getElementById('lightboxModal');
        const lightboxClose = document.getElementById('lightboxClose');
        const lightboxImage = document.getElementById('lightboxImage');
        const lightboxCaption = document.getElementById('lightboxCaption');
        const lightboxPrev = document.getElementById('lightboxPrev');
        const lightboxNext = document.getElementById('lightboxNext');

        // Photography data for lightbox
        const photographyData = [
            {
                src: "https://images.unsplash.com/photo-1501854140801-50d01698950b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1275&q=80",
                title: "Mountain Sunrise",
                category: "Nature"
            },
            {
                src: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1244&q=80",
                title: "City Lights",
                category: "Urban"
            },
            {
                src: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=776&q=80",
                title: "Human Expression",
                category: "Portrait"
            },
            {
                src: "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1073&q=80",
                title: "Floral Details",
                category: "Macro"
            },
            {
                src: "https://images.unsplash.com/photo-1487958449943-2429e8be8625?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
                title: "Modern Structures",
                category: "Architecture"
            },
            {
                src: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
                title: "Everyday Life",
                category: "Street"
            }
        ];

        let currentPhotoIndex = 0;

        // Preloader
        window.addEventListener('load', () => {
            setTimeout(() => {
                preloader.classList.add('hidden');
            }, 800);
        });

        // Theme Toggle
        function initTheme() {
            const savedTheme = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', savedTheme);
            updateThemeIcon(savedTheme);
        }

        function toggleTheme() {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            
            document.documentElement.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            updateThemeIcon(newTheme);
        }

        function updateThemeIcon(theme) {
            themeIcon.className = theme === 'light' ? 'fas fa-moon' : 'fas fa-sun';
        }

        themeToggle.addEventListener('click', toggleTheme);
        initTheme();

        // Mobile Navigation Toggle
        function toggleMobileMenu() {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
            mobileOverlay.classList.toggle('active');
            document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
        }

        function closeMobileMenu() {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
            mobileOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        hamburger.addEventListener('click', toggleMobileMenu);
        mobileOverlay.addEventListener('click', closeMobileMenu);

        // Close mobile menu when clicking a link
        navLinks.forEach(link => {
            link.addEventListener('click', closeMobileMenu);
        });

        // Header scroll effect
        window.addEventListener('scroll', () => {
            const header = document.getElementById('header');
            if (window.scrollY > 50) {
                header.classList.add('header-scrolled');
                
                // Hide scroll down indicator after scrolling
                if (scrollDownIndicator && window.scrollY > 300) {
                    scrollDownIndicator.style.opacity = '0';
                    scrollDownIndicator.style.visibility = 'hidden';
                }
            } else {
                header.classList.remove('header-scrolled');
                
                // Show scroll down indicator when at top
                if (scrollDownIndicator) {
                    scrollDownIndicator.style.opacity = '1';
                    scrollDownIndicator.style.visibility = 'visible';
                }
            }
        });

        // Scroll to top functionality
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                scrollToTopBtn.classList.add('show');
            } else {
                scrollToTopBtn.classList.remove('show');
            }
        });

        scrollToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // Portfolio Filter
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                // Remove active class from all buttons
                filterBtns.forEach(button => button.classList.remove('active'));
                // Add active class to clicked button
                btn.classList.add('active');
                
                const filterValue = btn.getAttribute('data-filter');
                
                portfolioItems.forEach(item => {
                    if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
                        item.style.display = 'block';
                        setTimeout(() => {
                            item.classList.add('visible');
                        }, 10);
                    } else {
                        item.classList.remove('visible');
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 300);
                    }
                });
            });
        });

        // Animate skill bars on scroll
        function animateSkillBars() {
            skillProgressBars.forEach(bar => {
                const percent = bar.getAttribute('data-percent');
                bar.style.width = percent + '%';
            });
        }

        // Animate elements on scroll
        function animateOnScroll() {
            const elements = document.querySelectorAll('.portfolio-item, .timeline-item, .education-item, .photography-item, .skill-progress, .hire-feature');
            const triggerBottom = window.innerHeight * 0.85;
            
            elements.forEach(element => {
                const elementTop = element.getBoundingClientRect().top;
                
                if (elementTop < triggerBottom) {
                    element.classList.add('visible');
                    
                    // Animate skill bars when in view
                    if (element.classList.contains('skill-progress')) {
                        const percent = element.getAttribute('data-percent');
                        element.style.width = percent + '%';
                    }
                }
            });
        }

        // Initial check on page load
        window.addEventListener('load', () => {
            setTimeout(animateOnScroll, 1000);
        });

        // Check on scroll
        window.addEventListener('scroll', animateOnScroll);

        // Photography Lightbox
        function openLightbox(index) {
            currentPhotoIndex = index;
            const photo = photographyData[index];
            lightboxImage.src = photo.src;
            lightboxImage.alt = photo.title;
            lightboxCaption.textContent = `${photo.title} - ${photo.category}`;
            lightboxModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeLightbox() {
            lightboxModal.classList.remove('active');
            document.body.style.overflow = '';
        }

        function navigateLightbox(direction) {
            currentPhotoIndex += direction;
            if (currentPhotoIndex < 0) currentPhotoIndex = photographyData.length - 1;
            if (currentPhotoIndex >= photographyData.length) currentPhotoIndex = 0;
            openLightbox(currentPhotoIndex);
        }

        // Add click event to photography items
        photographyItems.forEach((item, index) => {
            item.addEventListener('click', () => openLightbox(index));
        });

        // Lightbox controls
        lightboxClose.addEventListener('click', closeLightbox);
        lightboxPrev.addEventListener('click', () => navigateLightbox(-1));
        lightboxNext.addEventListener('click', () => navigateLightbox(1));

        // Optional JavaScript for "Load More" functionality
document.addEventListener('DOMContentLoaded', function() {
    const loadMoreBtn = document.getElementById('loadMoreCerts');
    
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            // You can implement AJAX loading here
            // For demonstration, we'll just show an alert
            alert('More certifications would be loaded here in a real implementation.');
            
            // Example: You could fetch more certifications and append to grid
            // fetchMoreCertifications().then(certifications => {
            //     appendCertifications(certifications);
            // });
        });
    }
});

        // Close lightbox on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowLeft') navigateLightbox(-1);
            if (e.key === 'ArrowRight') navigateLightbox(1);
        });

        // Close lightbox when clicking outside the image
        lightboxModal.addEventListener('click', (e) => {
            if (e.target === lightboxModal) closeLightbox();
        });

        // Contact form submission
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(contactForm);
            const data = Object.fromEntries(formData);
            
            // In a real application, you would send this data to a server
            console.log('Form submitted:', data);
            
            // Show success message
            showNotification('Message sent successfully! I\'ll get back to you soon.', 'success');
            
            // Reset form
            contactForm.reset();
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 70,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Set active nav link on scroll
        window.addEventListener('scroll', () => {
            let current = '';
            const sections = document.querySelectorAll('section[id]');
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (scrollY >= sectionTop - 100) {
                    current = section.getAttribute('id');
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${current}`) {
                    link.classList.add('active');
                }
            });
        });

        // Show notification function
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background-color: ${type === 'success' ? 'var(--primary-color)' : 'var(--accent-color)'};
                color: white;
                padding: 1rem 1.5rem;
                border-radius: var(--radius);
                box-shadow: var(--shadow-lg);
                z-index: 10000;
                animation: fadeIn 0.3s ease;
                max-width: 350px;
            `;
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'fadeOut 0.3s ease forwards';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 4000);
        }

        // Add CSS for notification animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(-20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            @keyframes fadeOut {
                from { opacity: 1; transform: translateY(0); }
                to { opacity: 0; transform: translateY(-20px); }
            }
        `;
        document.head.appendChild(style);

        // Handle window resize
        let resizeTimer;
        window.addEventListener('resize', () => {
            document.body.classList.add('resizing');
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                document.body.classList.remove('resizing');
            }, 250);
            
            // Close mobile menu on resize to larger screens
            if (window.innerWidth > 768) {
                closeMobileMenu();
            }
        });

        // Initialize animations on page load
        document.addEventListener('DOMContentLoaded', () => {
            // Set initial active nav link
            navLinks[0].classList.add('active');
            
            // Add scroll down click functionality
            if (scrollDownIndicator) {
                scrollDownIndicator.addEventListener('click', () => {
                    window.scrollTo({
                        top: window.innerHeight,
                        behavior: 'smooth'
                    });
                });
                
                scrollDownIndicator.style.cursor = 'pointer';
            }
            
        });