import express from 'express'
import cors from 'cors'
import sqlite3 from 'sqlite3'

const app = express()
app.use(cors())
app.use(express.json())

const db = new sqlite3.Database('./data.db')
db.serialize(() => {
  db.run('CREATE TABLE IF NOT EXISTS messages (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL, subject TEXT NOT NULL, message TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)')
  db.run('CREATE TABLE IF NOT EXISTS subscribers (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)')
})

app.get('/api/health', (req, res) => {
  res.json({ ok: true })
})

app.post('/api/contact', async (req, res) => {
  const { name, email, subject, message } = req.body || {}
  if (!name || !email || !subject || !message) return res.status(400).json({ error: 'invalid' })
  try {
    db.run('INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)', [name, email, subject, message], function (err) {
      if (err) return res.status(500).json({ error: 'failed' })
      res.json({ ok: true, id: this.lastID })
    })
  } catch (e) {
    res.status(500).json({ error: 'failed' })
  }
})

app.post('/api/subscribe', async (req, res) => {
  const { email } = req.body || {}
  if (!email) return res.status(400).json({ error: 'invalid' })
  try {
    db.run('INSERT OR IGNORE INTO subscribers (email) VALUES (?)', [email], function (err) {
      if (err) return res.status(500).json({ error: 'failed' })
      res.json({ ok: true, id: this.lastID })
    })
  } catch (e) {
    res.status(500).json({ error: 'failed' })
  }
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {})
